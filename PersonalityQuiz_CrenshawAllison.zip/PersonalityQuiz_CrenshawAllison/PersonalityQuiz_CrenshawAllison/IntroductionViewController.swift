//
//  ViewController.swift
//  PersonalityQuiz_CrenshawAllison
//
//  Created by Xcode Student on 12/5/19.
//  Copyright © 2019 Allison Crenshaw. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

